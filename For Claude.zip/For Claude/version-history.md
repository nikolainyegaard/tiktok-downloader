# Version History

Version is defined in `config.py` as `APP_VERSION` and rendered into the page header via `render_template("index.html", version=APP_VERSION)` in `web.py`.

When making changes, bump `APP_VERSION` in `config.py` before committing.

---

## v1.4.1 — user card layout polish (2026-04-04)
- Display name and `@handle` are now on separate lines — no more flex-wrapping that placed the handle beside or below the name inconsistently
- Old usernames moved from the id-line to the handle line, formatted as `@current · @old1 · @old2` (old names are smaller and muted)
- Bio area always reserves fixed vertical space (3-line height via `min-height`) so the stats row appears at a consistent position on every card regardless of bio length
- Bio overflow uses `-webkit-line-clamp: 3` with proper ellipsis instead of a hard `max-height` cutoff
- Status/privacy badges in a dedicated `.user-badges` column with `flex-shrink: 0` — no longer compete with the name for horizontal space
- CSS cleanup: new named classes `.user-identity`, `.user-badges`, `.user-bio-area`, `.user-card-footer`, `.user-old-names` replace inline styles

## v1.4.0 — per-user manual run button (2026-04-04)
- "Run" button added to each user card in the UI — triggers processing for that one user outside of the scheduled loop
- Multiple Run actions can be queued: clicking Run on several users queues them; they execute in order after the current one finishes
- Button shows "Queued" (disabled) while waiting and "Running…" (disabled) while active; reverts to "Run" once done
- New `_process_single_user(user, cookies)` coroutine extracted from `_process_all_users` — both the loop and manual runs call this
- New `_run_worker` daemon thread in `loop.py` processes the manual run queue one user at a time
- New `enqueue_user_run(tiktok_id)` public function; returns `False` if already queued or running
- `get_state_snapshot()` now includes `run_queue` (list of tiktok_ids) and `run_current` in its response
- New API endpoint: `POST /api/users/<tiktok_id>/run`
- "Processing @username (ID: ...)" log lines are now blue (same accent colour as `=== Loop` separators)

## v1.3.11 — update-on-duplicate add (2026-04-02)
- When adding a user whose TikTok ID already exists in the DB (e.g. after a username change), `_process_add` now calls `update_user_info` before returning the "already being tracked" error
- This patches missing fields (e.g. `sec_uid`) and records the current username in `username_history`
- Frontend error message is unchanged; the update happens silently in the background
- Fixes users added before `sec_uid` was introduced (e.g. `@maple_cl4ws`) — re-adding under new username backfills `sec_uid` so the loop can find them

## v1.3.10 — (no release; version reserved)

## v1.3.9 — profile fetch fix (2026-04-02)
- Fix: always pass `username` to `api.user()` even when `sec_uid` is available; previously sec_uid alone caused "You must provide the username" error from TikTokApi's `.info()`
- `get_user_info` now passes both `username` and `sec_uid` to `api.user(**kwargs)` when both are known

## v1.3.8 — public/private visibility badge (2026-04-02)
- Replace incorrect `secret=banned` mapping with a `privacy_status` field: `public` / `private_accessible` / `private_blocked`
- `secret` flag from TikTokApi now correctly interpreted as "private account" rather than "banned"
- `privacy_status` updated each loop: profile fetch determines public/private; yt-dlp success/failure on private accounts determines accessible vs blocked
- UI shows colour-coded badge below active/banned label: green "Public", green "Private" (has access), red "Private" (no access)
- Auto-ban detection via `secret` flag removed; `account_status` is now a manual-only field
- DB: new `privacy_status TEXT DEFAULT 'public'` column on users; migration added

## v1.3.7 — username-change folder rename (2026-04-02)
- When the loop detects a username change, rename `videos/@old/` → `videos/@new/` on disk
- If target folder already exists, files are merged individually then old folder removed
- All `file_path` values in videos table bulk-updated via `REPLACE()` in a single query
- New: `rename_user_folder(old, new)` in `downloader.py`, `rename_user_video_paths(tiktok_id, old, new)` in `database.py`

## v1.3.6 — deletion/ban confirmation threshold + ID-based lookups (in progress)
- All profile and video-list lookups in the loop now use TikTok ID instead of username — survives username changes
- `get_user_info` accepts `username=` or `user_id=`; loop passes `user_id`, add-user flow passes `username`
- `get_user_videos` takes `tiktok_id` and uses `tiktokuser:{id}` URL format (yt-dlp's own suggested format)
- `_CONFIRM_THRESHOLD = 3` in loop.py: deletions and bans require 3 consecutive loop runs before becoming official
- Positive changes (deleted→active, banned→active) remain immediate with no threshold
- DB gains `pending_deletion_count/since` on videos and `pending_ban_count/since` on users; `_migrate_db()` adds columns to existing DBs
- `update_user_info` no longer takes `account_status`; handled separately via `set_user_account_status` / `increment_user_pending_ban` / `clear_user_pending_ban`
- Loop no longer runs on startup — sleeps first, then runs; use Run Now for the first run
- `from __future__ import annotations` added to tiktok_api.py for Python <3.10 union syntax compatibility

## v1.3.5 — skipped (changes bundled into v1.3.6)

## v1.3.4 — autofill suppression + version display (2026-04-02)
- Replace username `<input>` with a `contenteditable` div — Safari's Passwords/Keychain integration only targets `<input>` elements; div is invisible to it
- Add `APP_VERSION` to `config.py`; display as `v1.3.4` in the page header via `render_template`
- Earlier attempts all failed: `autocomplete="off"`, `"new-password"`, `"one-time-code"`, `type="search"`

## v1.3.3 — Safari autofill fix attempt (2026-04-01)
- `autocomplete="new-password"` on username input (partially effective, did not suppress iCloud Passwords extension)
- Commit: `b71558c`

## v1.3.2 — DB write after download (2026-03-30)
- `db.add_video()` moved to after a successful download, so failed downloads are retried next loop
- Commit: `e125ad5`

## v1.3.1 — Google Chrome preference (2026-03-30)
- Dockerfile installs Google Chrome on amd64; arm64 falls back to Playwright Chromium
- `CHROME_EXECUTABLE` detected via `shutil.which` at runtime, passed to `create_sessions()`
- Fresh TikTokApi session created per user (fixes "No sessions created" error on later users)
- Commit: `1c5086a`

## v1.3.0 — Deleted file prefixing (2026-03-30)
- Videos deleted on TikTok have files renamed to `del_{filename}` on disk
- If a video reappears it is renamed back; `file_path` in DB updated accordingly
- Fixed repeated "deleted" log spam: `active_ids` now includes `status='undeleted'`
- New functions in `downloader.py`: `prefix_video_files`, `unprefix_video_files`
- New function in `database.py`: `update_video_file_path`
- Commit: `ab9eb11`

## v1.2.3 — Log stall, error dismissal, cookie overwrite fixes (2026-03-30)
- Log panel stall fix: server now returns full deque instead of a sliding window
- Queue error dismissal calls `DELETE /api/queue/<username>` server-side, so errors don't reappear on reload or from other devices
- Cookie upload now explicitly deletes existing file before saving (clean overwrite)
- Commit: `a7a4fd5`

## v1.2.2 — Caddy docker-compose example (2026-03-30)
- Added `docker-compose.override.yml` example with Caddy network integration
- Commit: `f2760ac` (with a reverted attempt before it: `a1fe619` / `12f4b86`)

## v1.2.1 — Grammar and syntax cleanup (2026-03-29)
- Minor copy/code cleanup pass, no functional changes
- Commit: `93af513`

## v1.2.0 — Switch to yt-dlp for video listing (2026-03-29)
- `get_user_videos()` replaced with yt-dlp flat playlist extraction (TikTokApi was being bot-detected for video lists)
- `get_video_details()` added: `curl_cffi` with Chrome impersonation scrapes `__UNIVERSAL_DATA_FOR_REHYDRATION__` JSON for video type and image URLs
- `get_cookies_flat()` and `get_cookies_for_playwright()` added to `config.py`
- `curl_cffi` added to `requirements.txt`; `yt-dlp` changed to `yt-dlp[default]`
- Random 2–5s inter-user delay added to loop
- Commit: `f146867`

## v1.1.0 — Photo posts, queue-based add, UI improvements (2026-03-29)
- Photo posts downloaded as individual `.jpg` files (`{video_id}_01.jpg`, `_02.jpg`, …)
- File mtime set to TikTok upload timestamp after every download
- Queue-based user add: input clears immediately, background worker processes lookups, pending/error indicators shown in UI
- Username input sanitisation (client + server)
- Client-side log clear button
- "Last: 2h ago" on fresh start fixed (server emits UTC ISO timestamps with timezone offset; frontend shows "Never run" when null)
- `requests` added to `requirements.txt`
- Commit: `562252f`

## v1.0.0 — Complete rewrite (2026-03-29)
- Full replacement of the old sound-ID-based downloader (`tiktokdownloader2.py`)
- New architecture: Flask web UI, SQLite DB, yt-dlp downloads, TikTokApi for profile info
- Files: `config.py`, `database.py`, `tiktok_api.py`, `downloader.py`, `loop.py`, `web.py`, `main.py`, `templates/index.html`, `Dockerfile`, `docker-compose.yml`
- Commit: `d41c113`

---

## Pre-rewrite history (old program, for reference)

The original program (`tiktokdownloader2.py`) monitored a TikTok **Sound ID** for new uploads and downloaded matching videos. It used a JSON file for state, then later a proper data structure. All commits before `d41c113` belong to this era.
