# Project Overview

## What this is

A self-hosted TikTok archiver. It monitors a list of TikTok usernames, detects new/deleted/restored videos each loop cycle, and downloads them with embedded metadata. A Flask web UI provides management from any browser.

## Repository location

`/Users/nikolainyegaard/Documents/GitHub/tiktok-downloader/`

Published Docker image: `ghcr.io/nikolainyegaard/tiktok-downloader:latest`

## File map

```
tiktok-downloader/
├── main.py          — entry point; starts Flask + loop thread; tees stdout to log files
├── config.py        — all env var config + cookie parsing helpers
├── database.py      — SQLite3 schema + all DB operations
├── tiktok_api.py    — TikTok data fetching (profile info, video list, video detail page)
├── downloader.py    — yt-dlp video download + direct photo download
├── loop.py          — background download loop, shared state, public accessors
├── web.py           — Flask app; all API routes; add-user queue worker
├── templates/
│   └── index.html   — single-page dark-theme UI (vanilla JS, no build step)
├── Dockerfile
├── docker-compose.yml
├── docker-compose.override.yml  — gitignored; used for local dev overrides
├── requirements.txt
├── README.md
└── For Claude/      — this folder; gitignored
```

## Runtime architecture

- **Main thread**: Flask (via `app.run`)
- **Loop thread** (`daemon=True`): runs `run_loop()` repeatedly with `LOOP_INTERVAL_MINUTES` sleep between iterations (default 180 min)
- **Add-worker thread** (`daemon=True`): single background worker that processes the add-user queue one entry at a time
- `asyncio.run()` is called inside threads (not the main thread) — creates a fresh event loop per call, which is safe
- All shared `loop_state` writes are guarded by `_state_lock` (threading.Lock)
- `trigger_event` (threading.Event) lets the web UI kick off an immediate loop run

## Environment variables

| Variable               | Default      | Purpose                          |
|------------------------|--------------|----------------------------------|
| `DATA_DIR`             | `./data`     | DB + cookies.txt location        |
| `VIDEOS_DIR`           | `./videos`   | Downloaded files root            |
| `LOOP_INTERVAL_MINUTES`| `30`         | Minutes between loop runs (use 180 in production) |
| `WEB_PORT`             | `5000`       | Flask listen port                |
| `TZ`                   | (system)     | Timezone for log timestamps      |
| `ms_token`             | —            | Fallback msToken if no cookies.txt |

## Data layout

```
data/
  tiktok.db       — SQLite database
  cookies.txt     — Netscape-format TikTok cookies (uploaded via UI)
  logs/
    transcript.log   — daily-rotating stdout/stderr tee (30 days kept)

videos/
  @username/
    {video_id}.mp4         — regular video
    {video_id}_01.jpg      — photo post (one file per image)
    del_{video_id}.mp4     — video marked deleted on TikTok (prefixed)
```
