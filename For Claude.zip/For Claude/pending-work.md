# Pending Work & Known Issues

## Status of "temp issues" file (as of 2026-04-02)

All 7 issues have been implemented. Confirmed via git history.

| # | Issue | Status | Commit |
|---|-------|--------|--------|
| 1 | "Last: 2h ago" on fresh start | Fixed — server emits UTC ISO timestamps with timezone offset; frontend shows "Never run" when null | 562252f |
| 2 | Track-a-user locks input | Fixed — queue-based add, 202 response, input clears immediately | 562252f |
| 3 | Clear log button | Fixed — client-side `logClearIndex`, "Clear" button in log header | 562252f |
| 4 | Username input sanitisation | Fixed — `oninput` regex on frontend, `re.sub` on backend | 562252f |
| 5 | Photo posts as individual images | Fixed — `get_video_details()` scrapes image URLs, `download_photos()` saves JPEGs | 562252f |
| 6 | File mtime = upload date | Fixed — `os.utime()` after download in both `download_video` and `download_photos` | 562252f |
| 7 | Bot detection / empty response | Fixed — switched video listing to yt-dlp flat extraction; curl_cffi for page scraping | f146867 |

---

## Nothing currently pending

There is no known outstanding work as of 2026-04-04. If you are starting a new session, read the user's messages carefully for new requests.

---

## Potential future work (not requested, do not implement unless asked)

- Photo EXIF metadata embedding (no metadata written to images currently)
- UI page for browsing per-user video list (endpoint exists: `GET /api/users/<id>/videos`)
- Pagination or search in the user grid for large user counts
- Webhook/notification on new downloads
- Re-download button for failed videos from the UI
- Slideshow video rendering for photo posts (explicitly declined — user prefers individual JPEGs)
