# Change Checklist

Run through this after every change before writing the commit message.

---

## 1. Version number
- [ ] Bump `APP_VERSION` in `config.py`
  - Patch (x.x.**X**): bug fixes, small UI tweaks, minor behaviour changes
  - Minor (x.**X**.0): new features, new DB columns, new API endpoints
  - Major (**X**.0.0): complete rewrites or breaking changes

---

## 2. For Claude — version-history.md
- [ ] Add a new entry at the top with version number, short title, date, and bullet points describing what changed and why
- [ ] If the version was marked "(in progress)" from a previous session, remove that tag and add the date

---

## 3. For Claude — modules.md
- [ ] Update any function signatures that changed
- [ ] Update any schema sections if DB columns were added/removed
- [ ] Update the loop flow list if the processing order or logic changed
- [ ] Update the API routes table if endpoints were added/changed/removed
- [ ] Update JS state variables section if frontend state changed

---

## 4. For Claude — decisions-and-gotchas.md
- [ ] Add a new section if a non-obvious decision was made (e.g. a workaround, a "we tried X and it failed" note, a reason for an unusual pattern)
- [ ] Update an existing section if the approach changed

---

## 5. For Claude — pending-work.md
- [ ] Mark any completed items as done
- [ ] Add any new known issues or future work discovered during this change

---

## 6. README.md
- [ ] Update if user-facing behaviour changed (startup behaviour, new features, config options, data layout, etc.)
- [ ] Does NOT need updating for internal refactors the user never sees

---

## 7. Commit message
- [ ] First line: short imperative summary (≤50 chars)
- [ ] Body: what changed and why, grouped logically
- [ ] Mention any DB migrations or breaking changes explicitly
- [ ] **Do NOT run the commit yourself** — provide the title and body to the user and let them commit
