# Module Reference

## config.py

Central config. All other modules import from here — never use `os.environ` directly elsewhere.

Key exports:
- `DATA_DIR`, `VIDEOS_DIR`, `COOKIES_PATH`, `LOOP_INTERVAL_MINUTES`, `WEB_PORT`
- `CHROME_EXECUTABLE` — `shutil.which("google-chrome")` or `None`; passed to TikTokApi to prefer real Chrome over Playwright Chromium (better bot resistance on amd64)
- `get_ms_token() -> str | None` — reads msToken from cookies.txt (Netscape format, field[5] name, field[6] value); falls back to `ms_token` env var
- `get_cookies_flat() -> dict` — full cookies.txt as `{name: value}` dict; used by loop.py to pass to `get_video_details()`
- `get_cookies_for_playwright() -> list[dict]` — Playwright-format cookie dicts for TikTokApi sessions (currently unused but available)
- `cookies_info() -> dict` — `{present, updated_at, size_bytes}` for the web UI

Cookie file parsing handles `#HttpOnly_` prefixed lines (strips the prefix before parsing).

---

## database.py

SQLite3 with WAL mode. `get_db()` is a contextmanager that commits on exit, rolls back on exception.

### Schema

**users**
```
tiktok_id TEXT PK, username, display_name, bio,
follower_count, following_count, video_count, join_date,
account_status (active|banned), added_at, last_checked, enabled,
pending_ban_count INTEGER DEFAULT 0, pending_ban_since INTEGER
```

**username_history**
```
id PK AUTOINCREMENT, tiktok_id FK, old_username, new_username, changed_at
```

**videos**
```
video_id TEXT PK, tiktok_id FK, type (video|photo),
description, upload_date, download_date, file_path,
status (up|deleted|undeleted), deleted_at, undeleted_at,
pending_deletion_count INTEGER DEFAULT 0, pending_deletion_since INTEGER
```

`_migrate_db(conn)` adds the four pending columns to existing DBs (try/except per ALTER TABLE, so safe to run on any DB version).

### Key functions
- `get_video_id_sets(tiktok_id) -> tuple[set, set]` — returns `(known_ids, active_ids)`. active = status in ('up', 'undeleted'). Pending-deletion videos still have status='up' so they remain in active_ids.
- `get_all_video_stats() -> dict` — aggregate SQL keyed by tiktok_id; avoids N+1 in list_users
- `get_all_username_history() -> dict` — all history in one query, keyed by tiktok_id
- `update_video_file_path(video_id, file_path)` — used when delete/undelete renames files
- `rename_user_video_paths(tiktok_id, old_username, new_username)` — bulk `REPLACE()` on all `file_path` values for a user; called after folder rename
- `update_user_info(...)` — does NOT take or set `account_status`; handled separately via pending functions
- `mark_video_deleted` — uses `pending_deletion_since` as `deleted_at`, clears pending fields
- `mark_video_undeleted` — clears pending fields
- `set_user_account_status(tiktok_id, status)` — direct status write, used for immediate changes
- `increment_user_pending_ban(tiktok_id) -> int` — increments counter, sets `pending_ban_since` on first call, returns new count
- `clear_user_pending_ban(tiktok_id)` — resets both pending ban fields to 0/NULL
- `get_pending_deletion_video_ids(tiktok_id) -> set` — returns video_ids with `pending_deletion_count > 0`
- `increment_video_pending_deletion(video_id) -> int` — increments counter, sets `pending_deletion_since` on first call, returns new count
- `clear_video_pending_deletion(video_id)` — resets both pending deletion fields to 0/NULL

---

## tiktok_api.py

Three functions:

**`async get_user_info(api, username=None, sec_uid=None) -> dict`**
- Requires an already-initialised TikTokApi `api` object
- Pass `username=` on first add (before sec_uid is known). Pass `sec_uid=` once it is stored — works even after a username change since TikTokApi accepts sec_uid for `.info()`.
- Returns: `tiktok_id, sec_uid, username, display_name, bio, join_date, follower_count, following_count, video_count, is_private`
- `is_private = True` if `user["secret"]` is truthy

**`get_user_videos(tiktok_id, cookies_path=None) -> list[dict]`**
- Synchronous. Uses yt-dlp flat extraction with URL `tiktokuser:{tiktok_id}` — works even after username changes
- Returns: `[{video_id, description, upload_date}]`
- Does NOT determine video type here — type is resolved later in `get_video_details()`

**`get_video_details(video_id, username, cookies) -> dict`**
- Synchronous. Uses `curl_cffi` (impersonates Chrome) to fetch the TikTok video page HTML
- Parses `__UNIVERSAL_DATA_FOR_REHYDRATION__` JSON blob from `<script>` tag
- Returns: `{type, description, upload_date, image_urls}`
- `type = "photo"` if `imagePost` key is present in item data
- `image_urls` = list of CDN URLs from `imagePost.images[*].imageURL.urlList[0]`

### Important: two-step fetch pattern
The loop fetches all video IDs cheaply via `get_user_videos` (yt-dlp flat), then calls `get_video_details` per new video only to get type + image URLs. This avoids the expensive page fetch for known videos.

---

## downloader.py

**`download_video(*, video_id, username, tiktok_id, display_name, description, upload_date, download_date) -> str | None`**
- Uses yt-dlp with FFmpegMetadata postprocessor
- Output: `VIDEOS_DIR/@username/{video_id}.mp4`
- Embeds: title, artist (username), album_artist (display_name), date, comment (pipe-delimited metadata blob)
- Calls `os.utime(path, (upload_date, upload_date))` after download so file mtime = TikTok upload date
- Returns file path on success, None on failure
- Cleans up partial/corrupt files (< 10KB) on failure

**`download_photos(*, video_id, username, image_urls, upload_date) -> str | None`**
- Downloads each image URL directly via `requests.get` with cookies from `_load_cookies()`
- Output: `VIDEOS_DIR/@username/{video_id}_01.jpg`, `_02.jpg`, etc.
- Sets mtime = upload_date on each image
- Returns path of first image, or None if all failed

**File management helpers:**
- `prefix_video_files(video_id, username)` — renames `{id}.mp4` → `del_{id}.mp4` when video is deleted on TikTok; returns new first-file path for DB update
- `unprefix_video_files(video_id, username)` — reverses the above when video is restored
- `rename_user_folder(old_username, new_username) -> bool` — renames `VIDEOS_DIR/@old` → `VIDEOS_DIR/@new`; merges files if target already exists; returns True on success or if old folder doesn't exist
- `_get_video_files(folder, video_id)` — shared: finds all files whose name starts with `video_id`
- `_find_output` and `_remove_corrupt` use `_get_video_files`

**Note:** `ydl_opts` is typed `dict[str, Any]` and the YoutubeDL call has `# type: ignore[arg-type]` because yt-dlp's own stubs define `_Params` incompatibly.

---

## loop.py

### Shared state
```python
loop_state = {
    "running": bool,
    "last_run_start": ISO string | None,
    "last_run_end":   ISO string | None,  # UTC isoformat
    "next_run":       ISO string | None,  # UTC isoformat; set by main.py after each run
    "current_user":   str | None,
    "logs":           deque(maxlen=1000),
}
_run_state = {
    "current": str | None,  # tiktok_id currently being run manually
    "queue":   list[str],   # tiktok_ids waiting in the manual run queue
}
```
All writes to `loop_state` use `_state_lock`; all writes to `_run_state` use `_run_state_lock`. Public accessors (`is_running`, `set_next_run`, `get_state_snapshot`, `enqueue_user_run`) encapsulate these locks so web.py never touches them directly.

### Confirmation threshold

`_CONFIRM_THRESHOLD = 3` — number of consecutive loops a negative change must persist before it becomes official. Applies to video deletion and user banning. Positive changes (deleted→active, banned→active) are immediate with no threshold.

### Loop flow per user
Per-user logic lives in `_process_single_user(user, cookies)`. Both the scheduled loop (`_process_all_users`) and the manual run worker (`_run_worker`) call this coroutine. It sets `loop_state["current_user"]` at entry and clears it in a `finally` block.

1. Random sleep 2–5s between users in `_process_all_users` (not applied for manual runs)
2. Open fresh TikTokApi session via `_fetch_user_info(username)` (stored username) → update profile in DB. **Note:** TikTokApi requires a username for `.info()` — ID-only lookup is not supported by the library. Profile fetch may fail if username has changed, but video list fetch (step 4) is unaffected as it uses tiktok_id.
3. Account status: if active → immediate un-ban + clear pending. If banned and not yet official → increment pending ban counter; confirm at 3.
4. `get_user_videos(tiktok_id)` (yt-dlp, by ID) → get full remote ID set
5. Diff: new_ids, deleted_ids, undeleted_ids
6. Pending-deletion videos that reappeared in remote → `clear_video_pending_deletion` immediately
7. For each new_id: call `get_video_details()` → download via `download_video` or `download_photos`
8. For deleted_ids: `increment_video_pending_deletion`; at count 3 → `mark_video_deleted` + `prefix_video_files`
9. For undeleted_ids: `mark_video_undeleted` + `unprefix_video_files` immediately (no threshold)

### Important DB ordering
`db.add_video()` is called AFTER a successful download, not before. This means failed downloads don't leave orphaned DB rows.

---

## web.py

### Add-user queue system
- Module-level: `_add_queue` (Queue), `_pending` dict, `_pending_lock`
- `_add_worker` thread started at import time (daemon)
- POST `/api/users` — sanitises username (`re.sub(r'[^a-zA-Z0-9_.]', '', raw)`), checks duplicates by username, puts into queue, returns 202
- GET `/api/queue` — returns current `_pending` dict to frontend
- DELETE `/api/queue/<username>` — dismisses an error entry (cannot dismiss in-progress)
- On success: entry removed from `_pending`; frontend picks up the new user via next `/api/users` poll
- On error: entry stays in `_pending` with `status: "error"` until dismissed
- **Duplicate by TikTok ID:** if `_process_add` finds the fetched `tiktok_id` already in the DB (different username, same account), it calls `update_user_info` to patch `sec_uid` and record the username change, then returns "User is already being tracked". This handles users added before `sec_uid` was stored and users who changed their username.

### API routes summary
```
GET  /                              → renders index.html
GET  /api/cookies                   → cookies_info()
POST /api/cookies                   → upload cookies.txt
DEL  /api/cookies                   → delete cookies.txt
GET  /api/users                     → list with stats + history merged in (3 DB queries total)
POST /api/users                     → enqueue add (returns 202)
DEL  /api/users/<tiktok_id>         → remove user
GET  /api/users/<tiktok_id>/videos  → video list for user
POST /api/users/<tiktok_id>/run     → enqueue manual single-user run (409 if already queued/running)
GET  /api/queue                     → pending add-user entries
DEL  /api/queue/<username>          → dismiss error entry
GET  /api/status                    → loop state snapshot (includes log lines, run_queue, run_current)
POST /api/trigger                   → fire loop immediately
```

---

## main.py

- `_Tee` class tees stdout/stderr to a `TimedRotatingFileHandler` (`data/logs/transcript.log`, daily rotation, 30 days kept)
- Loop thread **sleeps first** (waits `LOOP_INTERVAL_MINUTES`), then calls `run_loop()` — so the loop does not run automatically on startup; use "Run Now" to trigger the first run manually
- `trigger_event.set()` from web.py wakes the loop early
- Flask runs in main thread: `app.run(host="0.0.0.0", port=WEB_PORT, debug=False, use_reloader=False)`

---

## templates/index.html

Single file, no build step. Pure vanilla JS, dark CSS theme with CSS variables.

### Polling intervals
- `/api/status` every 5s (includes logs)
- `/api/users` every 15s
- `/api/cookies` every 30s
- `/api/queue` every 3s

### JS state
```js
let users         = [];
let currentUser   = null;
let isRunning     = false;
let logLines      = [];     // all log lines received from server
let logClearIndex = 0;      // client-side clear: skip lines before this index
let pending       = {};     // add-queue state mirrored from /api/queue
const dismissed   = new Set(); // usernames dismissed by user this session
let runQueue      = [];     // tiktok_ids queued for manual run (from /api/status)
let runCurrent    = null;   // tiktok_id currently being run manually (from /api/status)
```

### User card layout
Each card is a flex column. Key CSS classes:
- `.user-identity` — left column: display name (block), handle line (block), id-line (block)
- `.user-badges` — right column: account status + privacy badges stacked vertically, `flex-shrink: 0`
- `.user-bio-area` — always rendered; `flex: 1` + `min-height: 52px` so stats row sits at a consistent vertical position regardless of bio length
- `.user-bio` — `-webkit-line-clamp: 3` overflow; only rendered if `u.bio` is set
- `.user-card-footer` — flex row: "Last checked" text left, Run+Remove buttons right
- `.user-old-names` — inline `<span>` appended to the handle line; shows old usernames as `· @old1 · @old2` in muted/smaller text

### Log clear
Client-side only. `clearLog()` sets `logClearIndex = logLines.length` and clears the DOM. `renderLogs` slices from `Math.max(logLines.length, logClearIndex)` — so previously seen lines are never re-rendered after a clear.

### Input sanitisation
`oninput` handler: `this.value = this.value.replace(/[^a-zA-Z0-9_.@]/g, '')` — live sanitisation in the text field. Server also sanitises via regex before queuing.

### "Last run" display
Shows `"Never run"` when `last_run_end` is null/falsy. Previously showed a wrong relative time on fresh start.
