# Design Decisions & Gotchas

## TikTok API approach: hybrid

The codebase uses two different methods to interact with TikTok:

| Task | Method | Why |
|------|--------|-----|
| Fetch user profile info | TikTokApi (Playwright) | Only reliable way to get follower counts, bio, banned status |
| Fetch video ID list | yt-dlp flat extraction | TikTokApi was failing with "empty response / bot detection" on video listing |
| Fetch video type + image URLs | curl_cffi (page scrape) | yt-dlp flat extract doesn't include imagePost data; TikTokApi also unreliable for this |
| Download videos | yt-dlp | Best quality selection, stream merging, metadata embedding |
| Download photos | direct HTTP (requests) | yt-dlp only returns audio for photo posts |

## Bot detection

TikTok actively blocks headless browsers. Mitigations in place:
- Google Chrome preferred over Playwright Chromium on amd64 (Dockerfile installs Chrome; `CHROME_EXECUTABLE` set in config.py via `shutil.which`)
- `curl_cffi` with `impersonate="chrome120"` for page scraping
- Random 2–5s sleep between users in the loop
- Fresh TikTokApi session per user (each call to `_fetch_user_info` opens and closes its own `async with TikTokApi()`)
- **Cookies are the single biggest factor** — a fresh, valid `cookies.txt` should be uploaded regularly

If bot detection errors occur: "TikTok returned an empty response. They are detecting you're a bot" — the fix is to upload a fresh cookies.txt. Headless=False is not viable in Docker.

## TikTokApi: fresh session per user

Each call to `_fetch_user_info()` in loop.py opens its own `async with TikTokApi()` context and closes it after fetching the one user's profile. This replaced an earlier approach of sharing a single session across all users in a loop run.

**Why:** Sharing one session caused "No sessions created" errors for users processed later in the run — the session appeared to expire or become invalid mid-loop. One session per user is slower but reliable.

## Keychain / password manager autofill suppression

Safari's native Passwords integration (macOS Keychain) only targets `<input>` and `<textarea>` elements. The username field is therefore a `contenteditable` div, which Safari ignores entirely.

```html
<div class="handle-input" id="handleInput" contenteditable="true"
     role="textbox" data-placeholder="@username" spellcheck="false"></div>
```

JS reads `el.textContent` instead of `el.value`. Events are attached in JS (not inline):
- `input` → sanitise to `[a-zA-Z0-9_.]` and restore cursor
- `keydown` → intercept Enter to call `addUser()`
- `paste` → prevent rich-text paste via `e.preventDefault()` + `execCommand('insertText')`

Placeholder is CSS `::before` with `content: attr(data-placeholder)` when `:empty`.

Attempts that did NOT work (tried in order — all still triggered Safari Passwords):
1. `autocomplete="off"`
2. `autocomplete="new-password"`
3. `id="handleInput"` + `autocomplete="one-time-code"`
4. `type="search"` + `autocomplete="off"`

## Log panel stall fix

Earlier versions returned a sliding window of the last N log lines from `/api/status`. The frontend used index-based diffing (`lines.slice(logLines.length)`) which broke once the server-side window started dropping old lines — the indices no longer aligned, causing the panel to stop updating.

**Fix:** `get_state_snapshot()` now returns the full deque (all up to 1000 lines) on every call. The frontend diff is always valid.

## Cookie upload overwrites cleanly

`web.py::upload_cookies` explicitly `os.remove(COOKIES_PATH)` before saving the new file. This prevents partial overwrites if the new file is smaller than the old one.

## asyncio in threads

`asyncio.run()` is called from non-main threads (loop thread, add-worker thread, Flask request handler). This is safe because `asyncio.run()` creates a new event loop each time. Never share an event loop across threads.

## Manual run queue

The "Run" button on each user card uses a separate `_run_worker` daemon thread with its own `_queue_module.Queue`. It calls `_process_single_user` exactly like the scheduled loop does.

The worker and the main loop thread are independent — they can run simultaneously. If both happen to process the same user at the same time, the worst case is a redundant download attempt. `db.add_video` uses `video_id` as primary key, so duplicate inserts from a race are harmless (the second insert raises `UNIQUE` and the file is overwritten).

The inter-user random delay (2–5s) is only applied by `_process_all_users` (the scheduled loop), not by the manual run worker.

`_run_state` tracks `{"current": tiktok_id | None, "queue": [tiktok_ids]}` for the UI. Protected by `_run_state_lock`. Exposed via `get_state_snapshot()` as `run_current` / `run_queue`.

## Thread safety

- `loop_state` (all keys) — protected by `_state_lock`
- `_run_state` (manual run queue) — protected by `_run_state_lock`
- `_pending` dict — protected by `_pending_lock`
- DB — SQLite WAL mode allows concurrent readers; `get_db()` opens/closes a connection per operation
- `trigger_event` — threading.Event, safe to set/wait from any thread

## File naming for deleted videos

When a video disappears from TikTok, files are renamed with a `del_` prefix:
- `7123456789.mp4` → `del_7123456789.mp4`
- `7123456789_01.jpg` → `del_7123456789_01.jpg`

This makes deleted content visually obvious in the file system. `file_path` in the DB is updated to the new prefixed path. On undelete, the prefix is removed.

`prefix_video_files` and `unprefix_video_files` in downloader.py handle this. They use `_get_video_files(folder, video_id)` which matches by filename prefix, so they handle both single files and multi-image photo posts.

## Photo posts

Photo posts are identified by `imagePost` key in the TikTok page's JSON blob. Downloaded as `{video_id}_01.jpg`, `{video_id}_02.jpg`, etc. The DB `file_path` stores the path of the first image only — this is intentional. `_find_output` and `_get_video_files` use prefix matching, so they naturally find all files for a given video_id.

No metadata embedding for photos (EXIF writing is not implemented). The mtime of each image file is set to the TikTok upload timestamp.

## Database ordering in the loop

`db.add_video()` is called **after** a successful download, not before. This means:
- Failed downloads = no DB row = will be retried next loop
- If download succeeds but add_video fails, the file exists but has no DB record — next loop iteration will see it as "new" and re-download (overwrite)

## N+1 avoidance in list_users

`web.py::list_users` does exactly 3 DB queries regardless of user count:
1. `get_all_users()`
2. `get_all_video_stats()` — aggregate GROUP BY
3. `get_all_username_history()` — all history in one query

These are merged in Python. Do not add per-user queries to this path.

## `from __future__ import annotations`

Present in `downloader.py` (and should be in any file using `X | Y` union syntax). This defers annotation evaluation, making `str | None` valid on Python < 3.10. Required because the Docker image uses Python 3.12 but Pylance checks against whatever Python the dev machine has.

## Docker / deployment

- The Dockerfile installs Google Chrome on amd64 only (not available for arm64/Apple Silicon)
- `docker-compose.override.yml` is gitignored — used for local dev (e.g. `build: .` instead of the published image)
- Port is bound to `127.0.0.1:5000` only — Caddy on the host proxies it
- Volumes: `./data:/app/data` (DB + cookies, **back this up**) and `./videos:/app/videos`
- `LOOP_INTERVAL_MINUTES` should be `180` in production (not the default 30)
- `TZ: "Europe/Oslo"` set in docker-compose.yml for local log timestamps

## Re-adding a user under a new username backfills missing data

`_process_add` in web.py checks for an existing user by **TikTok ID**, not by username. If the fetched `tiktok_id` already exists in the DB (e.g. a user changed their username and the old row is missing `sec_uid`), `update_user_info` is called before returning the "already being tracked" error.

This means:
- Re-adding `@maple_claws` (new username for existing `@maple_cl4ws`) patches `sec_uid` and logs `maple_cl4ws → maple_claws` in `username_history`
- The loop can then find the user by `sec_uid` on the next run
- The frontend still sees an error as expected — the update is silent

Users added before `sec_uid` was introduced (v1.3.6) have `sec_uid = NULL` in the DB. The loop's profile fetch falls back to username in that case, which fails after a rename. Re-adding under the new username is the recovery path.

## Pylance / type checking known issues

- `yt_dlp` cannot be resolved from source — yt-dlp isn't installed in the Pylance environment. Severity is Warning, not Error. Ignore.
- YoutubeDL call: `# type: ignore[arg-type]` — yt-dlp's `_Params` type is incompatible with `dict[str, Any]` per its own stubs

## Cookie file format

Netscape cookies.txt (tab-separated, 7 fields per line):
```
domain  flag  path  secure  expiry  name  value
```
Lines starting with `#` are comments, except `#HttpOnly_` which is a real cookie with the prefix stripped before parsing.

`get_ms_token()` looks for `name.lower() in ("mstoken", "ms_token")`.
